<?php
/*
Plugin Name: WPSP Charge Customer
Plugin URI: http://www.hztech.biz
Description: Charge customer when an accounts funds are less
Version: 0.0.1
Author: Hztech
Author URI: http://www.hztech.biz
*/